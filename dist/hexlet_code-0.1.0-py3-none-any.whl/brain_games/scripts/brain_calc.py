from brain_games.calc import game


def main():
    game()


if __name__ == '__main__':
    main()
