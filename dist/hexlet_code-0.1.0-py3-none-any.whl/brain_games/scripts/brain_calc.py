import random
import prompt
from brain_games.calc import welcome_user, random_numbers, operation, game

def main():
    game()

if __name__ == '__main__':
   main()
