from brain_games.even import game


def main():
    game()


if __name__ == '__main__':
    main()
