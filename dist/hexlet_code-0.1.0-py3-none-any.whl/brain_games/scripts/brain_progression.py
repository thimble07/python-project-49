from brain_games.progression import game


def main():
    game()


if __name__ == '__main__':
    main()
