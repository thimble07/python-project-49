### Hexlet tests and linter status:
[![Actions Status](https://github.com/thimble07/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/thimble07/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/26f9439fa9291ab582ad/maintainability)](https://codeclimate.com/github/thimble07/python-project-49/maintainability)
Пример игры brain-even: https://asciinema.org/a/2WUfL4NUYhLek31E4LRInuqK6
Пример игры brain-calc: https://asciinema.org/a/purUBCqmRiOSDyAGnf3AzSEWt
Пример игры brain-gcd: https://asciinema.org/a/7BNiBTqPAgYqbJnf9T8mycwfZ
Пример игры brain-progression: https://asciinema.org/a/3c541vsmYM1x26MkGBjVPdgY4
Пример игры brain-prime: https://asciinema.org/a/Q8q7nmMtPvYUgBrNkdAxrLJ5r
