### Hexlet tests and linter status:
[![Actions Status](https://github.com/thimble07/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/thimble07/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/26f9439fa9291ab582ad/maintainability)](https://codeclimate.com/github/thimble07/python-project-49/maintainability)
