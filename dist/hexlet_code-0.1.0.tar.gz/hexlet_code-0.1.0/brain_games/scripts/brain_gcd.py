from brain_games.gcd import game


def main():
    game()


if __name__ == '__main__':
    main()
