import prompt
import random
from brain_games.even import welcome_user, question, answer_user, chek_answer, game

def main():
	game()

if __name__ == '__main__':
	main()
