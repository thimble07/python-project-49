from brain_games.prime import game


def main():
    game()


if __name__ == '__main__':
    main()
